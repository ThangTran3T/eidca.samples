<?php
/**
 * EIDCA CMS – Wrapper: Demo Ký số Tài liệu
 */
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/helpers.php';

requireLogin();
$user = currentUser();

$row     = DB::row('SELECT * FROM users WHERE id=? LIMIT 1', [$user['id']]);
$nfcUrl  = $row['nfc_url'] ?: DEFAULT_NFC_URL;
$camUrl  = $row['cam_url'] ?: DEFAULT_CAM_URL;
$apiKey  = $row['api_key'] ?? '';

$htmlFile = dirname(__DIR__) . '/eidca_signing.html';

if (!file_exists($htmlFile)) {
    http_response_code(404);
    echo '<p style="font-family:sans-serif;padding:2rem">Không tìm thấy file demo: eidca_signing.html</p>';
    exit;
}

$html   = file_get_contents($htmlFile);
$base   = _base();

$inject = <<<JS
<!-- CMS Config Injection -->
<script>
window.EIDCA_NFC_URL     = '{$nfcUrl}';
window.EIDCA_CAM_URL     = '{$camUrl}';
window.EIDCA_API_KEY     = '{$apiKey}';
window.EIDCA_CMS_LOG_URL = location.origin + '{$base}/api/log_event.php';
window.eidcaLogEvent = function(action, payload) {
  payload = payload || {};
  fetch(window.EIDCA_CMS_LOG_URL, {
    method: 'POST',
    headers: {'Content-Type':'application/json','X-Api-Key':window.EIDCA_API_KEY},
    body: JSON.stringify({action: action, payload: payload})
  }).catch(function(){});
};
</script>
JS;

$html = str_replace('</head>', $inject . '</head>', $html);

$backLink = '<div style="position:fixed;top:10px;right:10px;z-index:99999">'
    . '<a href="' . $base . '/dashboard.html" '
    . 'style="background:#7c3aed;color:#fff;padding:7px 14px;border-radius:8px;'
    . 'font-family:Inter,sans-serif;font-size:13px;font-weight:600;text-decoration:none;'
    . 'box-shadow:0 2px 8px rgba(124,58,237,.4)">← CMS</a></div>';
$html = str_replace('<body>', '<body>' . $backLink, $html);

header('Content-Type: text/html; charset=utf-8');
echo $html;
